public static class GameSettings
{
    public static int playerStartingHealth = 100; // Default health
    public static int enemyCount = 20;            // Default enemy count
}
